<!-- Footer -->
<footer class="font-small bg-dark">
    <!-- Copyright -->
    <div class="text-light footer-copyright text-center py-3">© {{ now()->year }} Copyright:
        <a> Mai Đăng Khoa - UIT  </a>
    </div>
    <!-- Copyright -->

</footer>
<!-- Footer -->

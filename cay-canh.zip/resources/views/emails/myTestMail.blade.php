<!DOCTYPE html>
<html>
<head>
    <title>Test mail</title>
</head>
<body>
<h1>{{ $details['title'] }}</h1>
<p>{{ $details['body'] }}</p>

<p>Thank you</p>
</body>
</html>

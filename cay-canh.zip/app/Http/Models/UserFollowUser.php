<?php


namespace App\Http\Models;


use Illuminate\Database\Eloquent\Model;

class UserFollowUser extends Model
{
    protected $table = 'user_follow_user';
}

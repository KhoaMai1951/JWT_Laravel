<?php $__env->startSection('title', 'Chi tiết cây cảnh'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h5 class="card-header">Chi tiết cây cảnh chỉnh sửa của người dùng</h5>
        <?php if(session()->has('saved')): ?>
            <div class="alert alert-success">
                <strong>Đã update</strong>
            </div>
        <?php endif; ?>
        <div class="row">
        <div class="col-lg-12">
            <label>Hình ảnh: </label>
            <img class="mb-5" width="300" height="300" src="<?php echo e($server_plant->image_url); ?>" alt="" title="" />
        </div>
        </div>
        <div class="row">

            <div class="col-6">
                <h1>Chỉnh sửa của người dùng</h1>
                <form method="POST" action="/admin/server_plant/has_viewed">
                    <?php echo csrf_field(); ?>
                    <div class="form-group ">
                        <!--ID -->
                        <input hidden type="text"
                               name="server_plant_user_edit_id" value="<?php echo e($user_edit_plant->id); ?>" autocomplete="name" autofocus>
                        <input hidden type="text"
                               name="server_plant_id" value="<?php echo e($user_edit_plant->server_plant_id); ?>" autocomplete="name" autofocus>
                        <input hidden type="text"
                               name="user_id" value="<?php echo e($user_edit_plant->user_id); ?>" autocomplete="name" autofocus>
                        <!-- Tên thường gọi -->
                        <label class="required">Tên thường gọi</label>
                        <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                               placeholder="Tên thường gọi" name="common_name"
                               value="<?php echo e(old('name', $user_edit_plant->common_name)); ?>" autocomplete="name" autofocus>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!-- Tên khoa học -->
                        <label class="required">Tên khoa học</label>
                        <input class="form-control <?php $__errorArgs = ['scientific_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                               placeholder="Tên thường gọi" name="scientific_name"
                               value="<?php echo e(old('scientific_name', $user_edit_plant->scientific_name)); ?>" autocomplete="scientific_name" autofocus>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!-- Thông tin -->
                        <label class="required">Thông tin</label>
                        <textarea class="form-control <?php $__errorArgs = ['information'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                  placeholder="Thông tin" name="information"
                                  autocomplete="information" autofocus cols="40" rows="10"><?php echo e(old('information', $user_edit_plant->information)); ?></textarea>

                        <?php $__errorArgs = ['information'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>



                    <button type="submit" class="btn btn-primary">Duyệt xong</button>

                </form>
            </div>
            <div class="col-6">
                <h1>Dữ liệu hiện tại</h1>
                <form method="POST" action="/admin/server_plant/admin_update_for_user_edit">
                    <?php echo csrf_field(); ?>
                    <div class="form-group ">
                        <!--ID -->
                        <input hidden type="text"
                               name="server_plant_user_edit_id" value="<?php echo e($user_edit_plant->id); ?>" autocomplete="name" autofocus>
                        <input hidden type="text"
                               name="server_plant_id" value="<?php echo e($server_plant->id); ?>" autocomplete="name" autofocus>
                        <input hidden type="text"
                               name="id" value="<?php echo e($server_plant->id); ?>" autocomplete="name" autofocus>
                        <!-- Tên thường gọi -->
                        <label class="required">Tên thường gọi</label>
                        <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                               placeholder="Tên thường gọi" name="common_name"
                               value="<?php echo e(old('name', $server_plant->common_name)); ?>" autocomplete="name" autofocus>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!-- Tên khoa học -->
                        <label class="required">Tên khoa học</label>
                        <input class="form-control <?php $__errorArgs = ['scientific_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                               placeholder="Tên thường gọi" name="scientific_name"
                               value="<?php echo e(old('scientific_name', $server_plant->scientific_name)); ?>" autocomplete="scientific_name" autofocus>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!-- Thông tin -->
                        <label class="required">Thông tin</label>
                        <textarea class="form-control <?php $__errorArgs = ['information'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                  placeholder="Thông tin" name="information"
                                  autocomplete="information" autofocus cols="40" rows="10"><?php echo e(old('information', $server_plant->information)); ?></textarea>

                        <?php $__errorArgs = ['information'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>





                    <button type="submit" class="btn btn-primary">Lưu </button>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Khoa\Desktop\Laravel projects\cay-canh\resources\views//admin_pages/server_plant/detail_edit.blade.php ENDPATH**/ ?>
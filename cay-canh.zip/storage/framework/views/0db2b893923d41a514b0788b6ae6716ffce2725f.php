<!-- Footer -->
<footer class="font-small bg-dark">
    <!-- Copyright -->
    <div class="text-light footer-copyright text-center py-3">© <?php echo e(now()->year); ?> Copyright:
        <a> Mai Đăng Khoa - UIT  </a>
    </div>
    <!-- Copyright -->

</footer>
<!-- Footer -->
<?php /**PATH C:\Users\Khoa\Desktop\Laravel projects\cay-canh\resources\views/components/system_admin/footer.blade.php ENDPATH**/ ?>
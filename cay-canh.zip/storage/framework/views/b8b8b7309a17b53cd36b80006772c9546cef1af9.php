<?php $__env->startSection('title', 'Chi tiết cây cảnh'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h5 class="card-header">Thêm mới cây cảnh</h5>
        <?php if(session()->has('saved')): ?>
            <div class="alert alert-success">
                <strong>Đã thêm</strong>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <!-- TÊN KHOA HỌC -->
                <div class="form-group">
                    <label class="required">Tên khoa học</label>
                    <input class="form-control <?php $__errorArgs = ['scientific_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                           placeholder="Nhập tên khoa học"
                           name="scientific_name"
                           value="<?php echo e(old('scientific_name')); ?>"
                           autocomplete="name" autofocus>
                    <?php $__errorArgs = ['scientific_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- TÊN THƯỜNG GỌI -->
                <div class="form-group">
                    <label class="required">Tên thường gọi</label>
                    <input class="form-control <?php $__errorArgs = ['common_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                           placeholder="Nhập tên thường gọi"
                           name="common_name"
                           value="<?php echo e(old('common_name')); ?>"
                           autocomplete="name" autofocus>
                    <?php $__errorArgs = ['common_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- UPLOAD IMAGE -->
                <div class="form-group">
                    <input type="file" name="image" class="form-control">
                </div>
                <!-- BUTTONS -->
                <a class="btn btn-danger ml-2" href="/admin/server_plant/list_plant" role="button">Quay lại</a>
                <button type="submit" class="btn btn-primary">Lưu</button>

            </form>
        </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Khoa\Desktop\Laravel projects\cay-canh\resources\views//admin_pages/server_plant/add_plant.blade.php ENDPATH**/ ?>
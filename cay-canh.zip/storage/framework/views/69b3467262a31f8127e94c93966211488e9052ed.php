<?php $__env->startSection('title', 'Chi tiết cây cảnh'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .column {
            float: left;
            width: 33.33%;
            padding: 5px;
        }
    </style>
    <div class="card">
        <h5 class="card-header">Chi tiết chờ duyệt chuyên gia </h5>
        <?php if(session()->has('saved')): ?>
            <div class="alert alert-success">
                <strong>Đã update</strong>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <form method="POST" action="/admin/expert_pending/grant_expert">
                <?php echo csrf_field(); ?>
                <div class="form-group ">
                    <!--ID -->
                    <input hidden type="text"
                           name="id" value="<?php echo e($pendingExpert->id); ?>" autocomplete="name" autofocus>
                    <!--USER ID -->
                    <input hidden type="text"
                           name="user_id" value="<?php echo e($pendingExpert->user_id); ?>" autocomplete="name" autofocus>
                    <!--IMAGES -->
                    <input hidden type="text"
                           name="images" value="<?php echo e($pendingExpert->imagesForPendingExpert); ?>" autocomplete="name" autofocus>

                    <!-- Bio -->
                    <label><b>User id: </b></label> <p><?php echo e($pendingExpert->user_id); ?></p>
                    <!-- Bio -->
                    <label><b>Bio: </b></label> <p><?php echo e($pendingExpert->bio); ?></p>

                    <!-- Experience in -->
                    <label><b>Chuyên về: </b></label> <p><?php echo e($pendingExpert->experience_in); ?></p>

                    <!-- HÌNH ẢNH-->
                    <label><b>Hình ảnh: </b></label>
                    <div class="row">
                        <?php $__currentLoopData = $pendingExpert->imagesForPendingExpert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="column">
                                <img src="<?php echo e($image->dynamic_url); ?>" alt="Snow" style="width:100%">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

                <a class="btn btn-warning ml-2" href="/admin/expert_pending/list_pending" role="button">Quay lại</a>

                <button type="submit" class="btn btn-primary">Duyệt</button>

                <a class="btn btn-danger ml-2" href="" role="button">Xóa</a>

            </form>
        </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Khoa\Desktop\Laravel projects\cay-canh\resources\views//admin_pages/pending_expert/detail_pending.blade.php ENDPATH**/ ?>
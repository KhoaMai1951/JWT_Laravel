<?php $__env->startSection('title', 'Danh sách dữ liệu cây cảnh'); ?>

<?php $__env->startSection('content'); ?>
    <!-- TITLE -->
    <div class="alert alert-primary" role="alert">
        <h1>Danh sách cây cảnh</h1>
    </div>

    <?php if(session()->has('deleted')): ?>
        <div class="alert alert-success">
            <strong><?php echo app('translator')->get('custom_message.deleted'); ?></strong>
        </div>
    <?php endif; ?>

    <?php if(count($list) == 0): ?>
        <div class="alert alert-warning">
            <?php echo app('translator')->get('custom_message.no_item_found'); ?>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-bordered table-hover table-striped bg-light">
                <thead>
                <tr>
                    <th scope="col">STT</th>
                    <th scope="col">Tên thường gọi</th>
                    <th scope="col">Tên khoa học</th>
                    <th scope="col">Hình ảnh</th>
                    <th scope="col">Hành động</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($i+1); ?></th>
                        <td><?php echo e($plant->common_name); ?></td>
                        <td><?php echo e($plant->scientific_name); ?></td>
                        <td><img width="100" height="100" src="<?php echo e($plant->image_url); ?>" alt="" title="" />
                        </td>
                        <td>
                            <a class="btn btn-primary" href="/admin/server_plant/detail/<?php echo e($plant->id); ?>"
                               role="button">Chi tiết</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo $list->links(); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Khoa\Desktop\Laravel projects\cay-canh\resources\views//admin_pages/server_plant/list_plant.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Chi tiết cây cảnh'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <h5 class="card-header">Chi tiết cây cảnh đóng góp</h5>
    <?php if(session()->has('saved')): ?>
    <div class="alert alert-success">
        <strong>Đã update</strong>
    </div>
    <?php endif; ?>
    <div class="card-body">
        <form method="POST" action="/admin/server-plant/admin_update">
            <?php echo csrf_field(); ?>
            <label>Hình ảnh: </label>
            <img class="mb-5" width="300" height="300" src="<?php echo e($plant->image_url); ?>" alt="" title="" />
            <div class="form-group ">
                <!--ID -->
                <input hidden type="text"
                       name="id" value="<?php echo e($plant->id); ?>" autocomplete="name" autofocus>
                <!-- Tên thường gọi -->
                <label class="required">Tên thường gọi</label>
                <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                       placeholder="Tên thường gọi" name="common_name"
                       value="<?php echo e(old('name', $plant->common_name)); ?>" autocomplete="name" autofocus>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- Tên khoa học -->
                <label class="required">Tên khoa học</label>
                <input class="form-control <?php $__errorArgs = ['scientific_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                       placeholder="Tên thường gọi" name="scientific_name"
                       value="<?php echo e(old('scientific_name', $plant->scientific_name)); ?>" autocomplete="scientific_name" autofocus>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- Thông tin -->
                <label class="required">Thông tin</label>
                <textarea class="form-control <?php $__errorArgs = ['information'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                          placeholder="Thông tin" name="information"
                          autocomplete="information" autofocus cols="40" rows="5"><?php echo e(old('information', $plant->information)); ?></textarea>

                <?php $__errorArgs = ['information'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <a class="btn btn-danger ml-2" href="/admin/server_plant/list_plant" role="button">Quay lại</a>

            <a class="btn btn-info ml-2" href="/admin/server_plant/accept_contribute/<?php echo e($plant->id); ?>" role="button">Thêm vào DB chính thức</a>

            <button type="submit" class="btn btn-primary">Lưu</button>

        </form>
    </div>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Khoa\Desktop\Laravel projects\cay-canh\resources\views//admin_pages/server_plant/detail_contribute.blade.php ENDPATH**/ ?>
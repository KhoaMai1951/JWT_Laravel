<?php $__env->startSection('title', 'Danh sách dữ liệu cây cảnh'); ?>

<?php $__env->startSection('content'); ?>
    <!-- TITLE -->
    <div class="alert alert-primary" role="alert">
        <h1>Danh sách chuyên gia</h1>
    </div>

    <?php if(session()->has('deleted')): ?>
        <div class="alert alert-success">
            <strong><?php echo app('translator')->get('custom_message.deleted'); ?></strong>
        </div>
    <?php endif; ?>

    <?php if(count($users) == 0): ?>
        <div class="alert alert-warning">
            Không có dữ liệu
        </div>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>STT</th>
                <th>Username</th>
                <th>Email</th>
                <th width="300px;">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php if(!empty($users) && $users->count()): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($value->id); ?></td>
                        <td><?php echo e($value->username); ?></td>
                        <td><?php echo e($value->email); ?></td>
                        <td>
                            <a class="btn btn-info" href="/admin/expert_pending/pending_detail/<?php echo e($value->id); ?>">Chi tiết</a>
                            <button class="btn btn-danger">Xóa</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="10">There are no data.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>

        <?php echo $users->links(); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Khoa\Desktop\Laravel projects\cay-canh\resources\views//admin_pages/pending_expert/list_expert.blade.php ENDPATH**/ ?>
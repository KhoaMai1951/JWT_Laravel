<?php $__env->startSection('title', 'Danh sách dữ liệu cây cảnh'); ?>

<?php $__env->startSection('content'); ?>
    <!-- TITLE -->
    <div class="alert alert-primary" role="alert">
        <h1>Danh sách đang chờ duyệt chuyên gia</h1>
    </div>

    <?php if(session()->has('deleted')): ?>
        <div class="alert alert-success">
            <strong><?php echo app('translator')->get('custom_message.deleted'); ?></strong>
        </div>
    <?php endif; ?>

    <?php if(count($pendings) == 0): ?>
        <div class="alert alert-warning">
            Không có dữ liệu
        </div>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>id user</th>
                <th>username</th>
                <th>bio</th>
                <th>kinh nghiệm trong</th>
                <th width="300px;">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php if(!empty($pendings) && $pendings->count()): ?>
                <?php $__currentLoopData = $pendings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($value->user_id); ?></td>
                        <td><?php echo e($value->test); ?></td>
                        <td><?php echo e($value->bio); ?></td>
                        <td><?php echo e($value->experience_in); ?></td>
                        <td>
                            <a class="btn btn-info" href="/admin/expert_pending/pending_detail/<?php echo e($value->id); ?>">Chi tiết</a>
                            <button class="btn btn-danger">Xóa</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="10">There are no data.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>

        <?php echo $pendings->links(); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Khoa\Desktop\Laravel projects\cay-canh\resources\views//admin_pages/pending_expert/list_pending.blade.php ENDPATH**/ ?>
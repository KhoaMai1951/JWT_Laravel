<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Demo Upload File - Toidicode.com</title>
    <meta name="author" content="ThanhTai">
</head>
<body>
<form action="<?php echo e(url('test')); ?>" enctype="multipart/form-data" method="POST">
    <?php echo e(csrf_field()); ?>

    <input type="file" name="file" required="true">
    <br/>
    <input type="submit" value="upload">
</form>
</body>
</html>
<?php /**PATH C:\Users\Khoa\Desktop\Laravel projects\cay-canh\resources\views/demo_upload.blade.php ENDPATH**/ ?>